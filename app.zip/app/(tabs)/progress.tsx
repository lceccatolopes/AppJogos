import {
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';

import { useGame } from '@/context/GameContext';

const TOTAL_FASES_PALAVRA_OCULTA = 50;
const TOTAL_FASES_PALAVRA_EMBARALHADA = 50;
const TOTAL_FASES_PALAVRAS_CRUZADAS = 10;
const TOTAL_FASES_CACA_PALAVRAS = 10;

export default function ProgressScreen() {
  const {
    fasesPalavraConcluidas,
    fasesEmbaralhadaConcluidas,
    fasesCruzadasConcluidas,
    fasesCacaPalavrasConcluidas,
  } = useGame();

  const fasesOcultaConcluidas =
    fasesPalavraConcluidas.length;

  const fasesEmbaralhadaConcluidasTotal =
    fasesEmbaralhadaConcluidas.length;

  const fasesCruzadasConcluidasTotal =
    fasesCruzadasConcluidas.length;

  const fasesCacaPalavrasConcluidasTotal =
    fasesCacaPalavrasConcluidas.length;

  const porcentagemOculta = Math.round(
    (fasesOcultaConcluidas /
      TOTAL_FASES_PALAVRA_OCULTA) *
      100
  );

  const porcentagemEmbaralhada = Math.round(
    (fasesEmbaralhadaConcluidasTotal /
      TOTAL_FASES_PALAVRA_EMBARALHADA) *
      100
  );

  const porcentagemCruzadas = Math.round(
    (fasesCruzadasConcluidasTotal /
      TOTAL_FASES_PALAVRAS_CRUZADAS) *
      100
  );

  const porcentagemCacaPalavras = Math.round(
    (fasesCacaPalavrasConcluidasTotal /
      TOTAL_FASES_CACA_PALAVRAS) *
      100
  );

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <Text style={styles.eyebrow}>
          SEU PROGRESSO
        </Text>

        <Text style={styles.title}>
          Progresso
        </Text>

        <Text style={styles.description}>
          Acompanhe seu avanço em todos os modos de jogo.
        </Text>

        <View style={styles.gameCard}>
          <View style={styles.gameHeader}>
            <Text style={styles.gameTitle}>
              Palavra Oculta
            </Text>

            <Text style={styles.gamePercentage}>
              {porcentagemOculta}%
            </Text>
          </View>

          <Text style={styles.gameProgress}>
            {fasesOcultaConcluidas} de{' '}
            {TOTAL_FASES_PALAVRA_OCULTA} fases concluídas
          </Text>

          <View style={styles.progressBar}>
            <View
              style={[
                styles.progressFill,
                {
                  width: `${porcentagemOculta}%`,
                },
              ]}
            />
          </View>
        </View>

        <View style={styles.gameCard}>
          <View style={styles.gameHeader}>
            <Text style={styles.gameTitle}>
              Palavra Embaralhada
            </Text>

            <Text style={styles.gamePercentage}>
              {porcentagemEmbaralhada}%
            </Text>
          </View>

          <Text style={styles.gameProgress}>
            {fasesEmbaralhadaConcluidasTotal} de{' '}
            {TOTAL_FASES_PALAVRA_EMBARALHADA} fases concluídas
          </Text>

          <View style={styles.progressBar}>
            <View
              style={[
                styles.progressFill,
                {
                  width: `${porcentagemEmbaralhada}%`,
                },
              ]}
            />
          </View>
        </View>

        <View style={styles.gameCard}>
          <View style={styles.gameHeader}>
            <Text style={styles.gameTitle}>
              Palavras Cruzadas
            </Text>

            <Text style={styles.gamePercentage}>
              {porcentagemCruzadas}%
            </Text>
          </View>

          <Text style={styles.gameProgress}>
            {fasesCruzadasConcluidasTotal} de{' '}
            {TOTAL_FASES_PALAVRAS_CRUZADAS} fases concluídas
          </Text>

          <View style={styles.progressBar}>
            <View
              style={[
                styles.progressFill,
                {
                  width: `${porcentagemCruzadas}%`,
                },
              ]}
            />
          </View>
        </View>

        <View style={styles.gameCard}>
          <View style={styles.gameHeader}>
            <Text style={styles.gameTitle}>
              Caça-Palavras
            </Text>

            <Text style={styles.gamePercentage}>
              {porcentagemCacaPalavras}%
            </Text>
          </View>

          <Text style={styles.gameProgress}>
            {fasesCacaPalavrasConcluidasTotal} de{' '}
            {TOTAL_FASES_CACA_PALAVRAS} fases concluídas
          </Text>

          <View style={styles.progressBar}>
            <View
              style={[
                styles.progressFill,
                {
                  width: `${porcentagemCacaPalavras}%`,
                },
              ]}
            />
          </View>
        </View>

        <View style={styles.gameCardDisabled}>
          <View style={styles.gameHeader}>
            <Text style={styles.disabledTitle}>
              Sudoku
            </Text>

            <Text style={styles.disabledPercentage}>
              0%
            </Text>
          </View>

          <Text style={styles.disabledText}>
            Em breve
          </Text>
        </View>

        <View style={styles.gameCardDisabled}>
          <View style={styles.gameHeader}>
            <Text style={styles.disabledTitle}>
              Conexo
            </Text>

            <Text style={styles.disabledPercentage}>
              0%
            </Text>
          </View>

          <Text style={styles.disabledText}>
            Em breve
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#090B12',
  },

  content: {
    paddingHorizontal: 20,
    paddingTop: 35,
    paddingBottom: 40,
  },

  eyebrow: {
    color: '#9C7CFF',
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 2,
  },

  title: {
    color: '#F4E4B7',
    fontSize: 34,
    fontWeight: '900',
    marginTop: 4,
  },

  description: {
    color: '#8D919E',
    fontSize: 14,
    lineHeight: 21,
    marginTop: 10,
  },

  gameCard: {
    backgroundColor: '#151822',
    borderWidth: 1,
    borderColor: '#292D3A',
    borderRadius: 18,
    padding: 18,
    marginTop: 18,
  },

  gameCardDisabled: {
    backgroundColor: '#10131B',
    borderWidth: 1,
    borderColor: '#222631',
    borderRadius: 18,
    padding: 18,
    marginTop: 14,
    opacity: 0.55,
  },

  gameHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  gameTitle: {
    color: '#F4E4B7',
    fontSize: 19,
    fontWeight: '900',
  },

  gamePercentage: {
    color: '#9C7CFF',
    fontSize: 18,
    fontWeight: '900',
  },

  gameProgress: {
    color: '#777B88',
    fontSize: 12,
    marginTop: 8,
  },

  progressBar: {
    height: 8,
    backgroundColor: '#252936',
    borderRadius: 20,
    marginTop: 15,
    overflow: 'hidden',
  },

  progressFill: {
    height: '100%',
    backgroundColor: '#9C7CFF',
    borderRadius: 20,
  },

  disabledTitle: {
    color: '#777B88',
    fontSize: 17,
    fontWeight: '800',
  },

  disabledPercentage: {
    color: '#555A67',
    fontSize: 16,
    fontWeight: '900',
  },

  disabledText: {
    color: '#50545F',
    fontSize: 12,
    marginTop: 8,
  },
});