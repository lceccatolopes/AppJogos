import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import {
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';

type GameCardProps = {
  title: string;
  description: string;
  icon: keyof typeof Ionicons.glyphMap;
  info?: string;
  enabled?: boolean;
  onPress?: () => void;
};

function GameCard({
  title,
  description,
  icon,
  info,
  enabled = false,
  onPress,
}: GameCardProps) {
  return (
    <View
      style={[
        styles.gameCard,
        !enabled && styles.gameCardDisabled,
      ]}
    >
      <View style={styles.gameTop}>
        <View
          style={[
            styles.gameIcon,
            !enabled && styles.gameIconDisabled,
          ]}
        >
          <Ionicons
            name={icon}
            size={25}
            color={enabled ? '#FFFFFF' : '#666B78'}
          />
        </View>

        <View
          style={[
            styles.statusBadge,
            enabled
              ? styles.availableBadge
              : styles.comingBadge,
          ]}
        >
          <Text
            style={[
              styles.statusText,
              enabled
                ? styles.availableText
                : styles.comingText,
            ]}
          >
            {enabled ? 'DISPONÍVEL' : 'EM BREVE'}
          </Text>
        </View>
      </View>

      <Text
        style={[
          styles.gameTitle,
          !enabled && styles.gameTitleDisabled,
        ]}
      >
        {title}
      </Text>

      <Text
        style={[
          styles.gameDescription,
          !enabled && styles.gameDescriptionDisabled,
        ]}
      >
        {description}
      </Text>

      {info && (
        <Text style={styles.gameInfo}>
          {info}
        </Text>
      )}

      {enabled ? (
        <Pressable
          style={({ pressed }) => [
            styles.playButton,
            pressed && styles.playButtonPressed,
          ]}
          onPress={onPress}
        >
          <Text style={styles.playButtonText}>
            JOGAR
          </Text>
        </Pressable>
      ) : (
        <View style={styles.disabledButton}>
          <Text style={styles.disabledButtonText}>
            EM BREVE
          </Text>
        </View>
      )}
    </View>
  );
}

export default function HomeScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <View>
            <Text style={styles.eyebrow}>
              COLEÇÃO DE DESAFIOS
            </Text>

            <Text style={styles.title}>
              Jogos
            </Text>
          </View>

          <View style={styles.headerIcon}>
            <Ionicons
              name="game-controller"
              size={28}
              color="#9C7CFF"
            />
          </View>
        </View>

        <Text style={styles.description}>
          Escolha um modo, desafie sua mente e avance no seu ritmo.
        </Text>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>
            MODOS DE JOGO
          </Text>

          <Text style={styles.sectionCount}>
            6 jogos
          </Text>
        </View>

        <View style={styles.games}>
          <GameCard
            title="Palavra Oculta"
            description="Descubra a palavra escondida usando as pistas de posição das letras."
            icon="text"
            info="50 fases • 5 letras • 6 tentativas"
            enabled
            onPress={() =>
              router.push('/games/word-game')
            }
          />

          <GameCard
            title="Palavra Embaralhada"
            description="Reorganize as letras para descobrir a palavra correta."
            icon="shuffle"
            info="50 fases • 5 letras"
            enabled
            onPress={() =>
              router.push('/games/scrambled-word')
            }
          />

          <GameCard
            title="Palavras Cruzadas"
            description="Resolva as pistas e complete todas as palavras da fase."
            icon="grid"
            info="10 fases • pistas e respostas"
            enabled
            onPress={() =>
              router.push('/games/crossword')
            }
          />

         <GameCard
           title="Caça-Palavras"
           description="Encontre todas as palavras escondidas no tabuleiro."
           icon="search"
           info="10 fases • vários temas"
           enabled
           onPress={() =>
             router.push('/games/word-search')
        }
      />

          <GameCard
            title="Sudoku"
            description="Complete a grade usando lógica e raciocínio sem repetir números."
            icon="apps"
            info="Fácil • Médio • Difícil"
          />

          <GameCard
            title="Conexo"
            description="Encontre grupos de palavras que compartilham uma conexão em comum."
            icon="git-network"
            info="Categorias e associações"
          />
        </View>

        <Text style={styles.footer}>
          Novos modos poderão ser adicionados no futuro.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#090B12',
  },

  scrollContent: {
    paddingHorizontal: 20,
    paddingTop: 30,
    paddingBottom: 40,
  },

  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  eyebrow: {
    color: '#9C7CFF',
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 2,
  },

  title: {
    color: '#F4E4B7',
    fontSize: 36,
    fontWeight: '900',
    marginTop: 3,
  },

  headerIcon: {
    width: 52,
    height: 52,
    borderRadius: 16,
    backgroundColor: '#151822',
    borderWidth: 1,
    borderColor: '#292D3A',
    justifyContent: 'center',
    alignItems: 'center',
  },

  description: {
    color: '#858995',
    fontSize: 14,
    lineHeight: 21,
    marginTop: 14,
    maxWidth: 330,
  },

  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 32,
    marginBottom: 14,
  },

  sectionTitle: {
    color: '#6D7280',
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 1.8,
  },

  sectionCount: {
    color: '#555A67',
    fontSize: 11,
    fontWeight: '700',
  },

  games: {
    gap: 16,
  },

  gameCard: {
    backgroundColor: '#151822',
    borderWidth: 1,
    borderColor: '#303545',
    borderRadius: 20,
    padding: 19,
  },

  gameCardDisabled: {
    borderColor: '#232732',
  },

  gameTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  gameIcon: {
    width: 48,
    height: 48,
    borderRadius: 15,
    backgroundColor: '#7B5CFF',
    justifyContent: 'center',
    alignItems: 'center',
  },

  gameIconDisabled: {
    backgroundColor: '#20242F',
  },

  statusBadge: {
    borderRadius: 20,
    paddingHorizontal: 11,
    paddingVertical: 7,
  },

  availableBadge: {
    backgroundColor: '#17281F',
    borderWidth: 1,
    borderColor: '#2F6748',
  },

  comingBadge: {
    backgroundColor: '#1B1E27',
  },

  statusText: {
    fontSize: 9,
    fontWeight: '900',
    letterSpacing: 1,
  },

  availableText: {
    color: '#66D49A',
  },

  comingText: {
    color: '#626775',
  },

  gameTitle: {
    color: '#F4E4B7',
    fontSize: 21,
    fontWeight: '900',
    marginTop: 17,
  },

  gameTitleDisabled: {
    color: '#A7A9B2',
  },

  gameDescription: {
    color: '#858995',
    fontSize: 13,
    lineHeight: 20,
    marginTop: 7,
  },

  gameDescriptionDisabled: {
    color: '#666A75',
  },

  gameInfo: {
    color: '#5F6471',
    fontSize: 11,
    fontWeight: '700',
    marginTop: 13,
  },

  playButton: {
    height: 50,
    backgroundColor: '#7B5CFF',
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 18,
  },

  playButtonPressed: {
    opacity: 0.75,
    transform: [{ scale: 0.99 }],
  },

  playButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '900',
    letterSpacing: 2,
  },

  disabledButton: {
    height: 48,
    backgroundColor: '#1C202A',
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 18,
  },

  disabledButtonText: {
    color: '#555A67',
    fontSize: 12,
    fontWeight: '900',
    letterSpacing: 1.5,
  },

  footer: {
    color: '#484C57',
    fontSize: 11,
    textAlign: 'center',
    marginTop: 26,
  },
});